import React from 'react'
import './Component1.css'
function Skynight() {
  return (
    <div>
     
      <div  id='hell'>
      </div>
<img  src="https://www.pixelstalk.net/wp-content/uploads/2016/06/HD-Pictures-Night-Sky.jpg" height={"580px"} width={"1270px"}/>
 
</div>
  )
}

export default Skynight

