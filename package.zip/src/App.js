// //import logo from './logo.svg';
// // import './App.css';
// import Home from './Home';
// import Navcomponent from './Navcomponent';
// import { BrowserRouter,Routes,Route } from 'react-router-dom';
// import Service from './Service';
// import Contact from './Contact';
// import Me from './Me'
// import Studentsstatesample from './Studentsstatesample';
// import Studentstatecontent from './Studentstatecontent';

import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";
import Page1 from "./J.Project/Page1";
import Header2 from "./J.Project/Header2";
import Header3 from "./J.Project/Header3";
import Header5 from "./J.Project/Header5";
import Header6 from "./J.Project/Header6";
import Header7 from "./J.Project/Header7";
import Header8 from "./J.Project/Header8";
import Header9 from "./J.Project/Header9";
import Header1 from "./J.Project/Header1";
import Header10 from "./J.Project/Header10";
import Header11 from "./J.Project/Header11";
import Header12 from "./J.Project/Header12";
import Header121 from "./J.Project/Header121";
import Header122 from "./J.Project/Header122";
import Header13 from "./J.Project/Header13";
import FooterC from "./J.Project/FooterC";
import Footer from "./J.Project/Footer";
import FooterC1 from "./J.Project/FooterC1";
import FooterT from "./J.Project/FooterT";
import FooterP from "./J.Project/FooterP";
import FooterPA from "./J.Project/FooterPA";
import FooterAB from "./J.Project/FooterAB";
import H1 from "./J.Project/Page2/H1";
import HeaderAA from "./J.Project/Page2/HeaderAA";
import View from "./J.Project/Page2/View";
import Secure from "./J.Project/Page2/Secure";
import Hh from "./Baroque/Hh";
import Pic1 from "./J.Project/Page1Pic/Pic1";
import Pic1P1 from "./J.Project/Page1Pic/Pic1P1";
import Pic1P2 from "./J.Project/Page1Pic/Pic1P2";
import Pic1P3 from "./J.Project/Page1Pic/Pic1P3";
import Pic2P1 from "./J.Project/Page1Pic/Pic2P1";
import Pic2P2 from "./J.Project/Page1Pic/Pic2P2";
import Pic2P3 from "./J.Project/Page1Pic/Pic2P3";
import Pic3P1 from "./J.Project/Page1Pic/Pic3P1";
import Pic3P2 from "./J.Project/Page1Pic/Pic3P2";
import Pic3P3 from "./J.Project/Page1Pic/Pic3P3";
import Pic4P1 from "./J.Project/Page1Pic/Pic4P1";
import Pic4P2 from "./J.Project/Page1Pic/Pic4P2";
import Pic4P3 from "./J.Project/Page1Pic/Pic4P3";
import Pic5P1 from "./J.Project/Page1Pic/Pic5P1";
import Pic5P2 from "./J.Project/Page1Pic/Pic5P2";
import Pic5P3 from "./J.Project/Page1Pic/Pic5P3";
import Pic6P1 from "./J.Project/Page1Pic/Pic6P1";
import Pic6P2 from "./J.Project/Page1Pic/Pic6P2";
import Pic6P3 from "./J.Project/Page1Pic/Pic6P3";
import Pic7P1 from "./J.Project/Page1Pic/Pic7P1";
import Pic7P2 from "./J.Project/Page1Pic/Pic7P2";
import Pic7P3 from "./J.Project/Page1Pic/Pic7P3";
import Pic8P1 from "./J.Project/Page1Pic/Pic8P1";
import Pic8P2 from "./J.Project/Page1Pic/Pic8P2";
import Pic8P3 from "./J.Project/Page1Pic/Pic8P3";
import Pic9P1 from "./J.Project/Page1Pic/Pic9P1";
import Pic9P2 from "./J.Project/Page1Pic/Pic9P2";
import Pic9P3 from "./J.Project/Page1Pic/Pic9P3";
import Pic10P1 from "./J.Project/Page1Pic/Pic10P1";
import Pic10P2 from "./J.Project/Page1Pic/Pic10P2";
import Pic10P3 from "./J.Project/Page1Pic/Pic10P3";
import Pic11P1 from "./J.Project/Page1Pic/Pic11P1";
import Pic11P2 from "./J.Project/Page1Pic/Pic11P2";
import Pic11P3 from "./J.Project/Page1Pic/Pic11P3";
import Pic12P1 from "./J.Project/Page1Pic/Pic12P1";
import Pic12P2 from "./J.Project/Page1Pic/Pic12P2";
import Pic12P3 from "./J.Project/Page1Pic/Pic12P3";
import Pic13P1 from "./J.Project/Page1Pic/Pic13P1";
import Pic13P2 from "./J.Project/Page1Pic/Pic13P2";
import Pic13P3 from "./J.Project/Page1Pic/Pic13P3";
import Pic14P1 from "./J.Project/Page1Pic/Pic14P1";
import Pic14P2 from "./J.Project/Page1Pic/Pic14P2";
import Pic14P3 from "./J.Project/Page1Pic/Pic14P3";
import Pic15P1 from "./J.Project/Page1Pic/Pic15P1";
import Pic15P2 from "./J.Project/Page1Pic/Pic15P2";
import Pic15P3 from "./J.Project/Page1Pic/Pic15P3";
import Pic16P1 from "./J.Project/Page1Pic/Pic16P1";
import Pic16P2 from "./J.Project/Page1Pic/Pic16P2";
import Pic16P3 from "./J.Project/Page1Pic/Pic16P3";
import Pic17P1 from "./J.Project/Page1Pic/Pic17P1";
import Pic17P2 from "./J.Project/Page1Pic/Pic17P2";
import Pic17P3 from "./J.Project/Page1Pic/Pic17P3";
import Pic18P1 from "./J.Project/Page1Pic/Pic18P1";
import Pic18P2 from "./J.Project/Page1Pic/Pic18P2";
import Pic18P3 from "./J.Project/Page1Pic/Pic18P3";
import Pic21P1 from "./J.Project/Page2/Pic21P1";
import Pic21P2 from "./J.Project/Page2/Pic21P2";
import Pic21P3 from "./J.Project/Page2/Pic21P3";
import Pic22P1 from "./J.Project/Page2/Pic22P1";
import Pic22P2 from "./J.Project/Page2/Pic22P2";
import Pic22P3 from "./J.Project/Page2/Pic22P3";
import Pic23P1 from "./J.Project/Page2/Pic23P1";
import Pic23P2 from "./J.Project/Page2/Pic23P2";
import Pic23P3 from "./J.Project/Page2/Pic23P3";
import Pic24P1 from "./J.Project/Page2/Pic24P1";
import Pic24P2 from "./J.Project/Page2/Pic24P2";
import Pic24P3 from "./J.Project/Page2/Pic24P3";
import Pic25P1 from "./J.Project/Page2/Pic25P1";
import Pic25P2 from "./J.Project/Page2/Pic25P2";
import Pic25P3 from "./J.Project/Page2/Pic25P3";
import Pic26P1 from "./J.Project/Page2/Pic26P1";
import Pic26P2 from "./J.Project/Page2/Pic26P2";
import Pic26P3 from "./J.Project/Page2/Pic26P3";
import Pic27P1 from "./J.Project/Page2/Pic27P1";
import Pic27P2 from "./J.Project/Page2/Pic27P2";
import Pic27P3 from "./J.Project/Page2/Pic27P3";
import Pic28P1 from "./J.Project/Page2/Pic28P1";
import Pic28P2 from "./J.Project/Page2/Pic28P2";
import Pic28P3 from "./J.Project/Page2/Pic28P3";
import Pic29P1 from "./J.Project/Page2/Pic29P1";
import Pic29P2 from "./J.Project/Page2/Pic29P2";
import Pic29P3 from "./J.Project/Page2/Pic29P3";
import Pic30P1 from "./J.Project/Page2/Pic30P1";
import Pic30P2 from "./J.Project/Page2/Pic30P2";
import Pic30P3 from "./J.Project/Page2/Pic30P3";
import Pic31P1 from "./J.Project/Page2/Pic31P1";
import Pic31P2 from "./J.Project/Page2/Pic31P2";
import Pic31P3 from "./J.Project/Page2/Pic31P3";
import Pic32P1 from "./J.Project/Page2/Pic32P1";
import Pic32P2 from "./J.Project/Page2/Pic32P2";
import Pic32P3 from "./J.Project/Page2/Pic32P3";
import Pic33P1 from "./J.Project/Page2/Pic33P1";
import Pic33P2 from "./J.Project/Page2/Pic33P2";
import Pic33P3 from "./J.Project/Page2/Pic33P3";
import Pic34P1 from "./J.Project/Page2/Pic34P1";
import Pic34P2 from "./J.Project/Page2/Pic34P2";
import Pic34P3 from "./J.Project/Page2/Pic34P3";
import Pic35P1 from "./J.Project/Page2/Pic35P1";
import Pic35P2 from "./J.Project/Page2/Pic35P2";
import Pic35P3 from "./J.Project/Page2/Pic35P3";
import Pic36P1 from "./J.Project/Page2/Pic36P1";
import Pic36P2 from "./J.Project/Page2/Pic36P2";
import Pic36P3 from "./J.Project/Page2/Pic36P3";
import Pic37P1 from "./J.Project/Page2/Pic37P1";
import Pic37P2 from "./J.Project/Page2/Pic37P2";
import Pic37P3 from "./J.Project/Page2/Pic37P3";
import Pic38P1 from "./J.Project/Page2/Pic38P1";
import Pic38P2 from "./J.Project/Page2/Pic38P2";
import Pic38P3 from "./J.Project/Page2/Pic38P3";
import PP from "./J.Project/Page3/PP";
import Pic40P1 from "./J.Project/Page3/Pic40P1";
import Pic40P2 from "./J.Project/Page3/Pic40P2";
import Pic40P3 from "./J.Project/Page3/Pic40P3";
import Pic41P1 from "./J.Project/Page3/Pic41P1";
import Pic41P2 from "./J.Project/Page3/Pic41P2";
import Pic41P3 from "./J.Project/Page3/Pic41P3";
import Pic43P1 from "./J.Project/Page3/Pic43P1";
import Pic43P2 from "./J.Project/Page3/Pic43P2";
import Pic43P3 from "./J.Project/Page3/Pic43P3";
import Pic44P1 from "./J.Project/Page3/Pic44P1";
import Pic44P2 from "./J.Project/Page3/Pic44P2";
import Pic44P3 from "./J.Project/Page3/Pic44P3";
import Pic45P1 from "./J.Project/Page3/Pic45P1";
import Pic45P2 from "./J.Project/Page3/Pic45P2";
import Pic45P3 from "./J.Project/Page3/Pic45P3";
import Pic46P1 from "./J.Project/Page3/Pic46P1";
import Pic46P2 from "./J.Project/Page3/Pic46P2";
import Pic46P3 from "./J.Project/Page3/Pic46P3";
import Pic47P1 from "./J.Project/Page3/Pic47P1";
import Pic47P2 from "./J.Project/Page3/Pic47P2";
import Pic47P3 from "./J.Project/Page3/Pic47P3";
import Pic48P1 from "./J.Project/Page3/Pic48P1";
import Pic48P2 from "./J.Project/Page3/Pic48P2";
import Pic48P3 from "./J.Project/Page3/Pic48P3";
import Pic49P1 from "./J.Project/Page3/Pic49P1";
import Pic49P2 from "./J.Project/Page3/Pic49P2";
import Pic49P3 from "./J.Project/Page3/Pic49P3";
import Pic50P1 from "./J.Project/Page3/Pic50P1";
import Pic50P2 from "./J.Project/Page3/Pic50P2";
import Pic50P3 from "./J.Project/Page3/Pic50P3";
import Pic51P1 from "./J.Project/Page3/Pic51P1";
import Pic51P2 from "./J.Project/Page3/Pic51P2";
import Pic51P3 from "./J.Project/Page3/Pic51P3";
import Pic52P1 from "./J.Project/Page3/Pic52P1";
import Pic52P2 from "./J.Project/Page3/Pic52P2";
import Pic52P3 from "./J.Project/Page3/Pic52P3";
import Pic53P1 from "./J.Project/Page3/Pic53P1";
import Pic53P2 from "./J.Project/Page3/Pic53P2";
import Pic53P3 from "./J.Project/Page3/Pic53P3";
import Pic54P1 from "./J.Project/Page3/Pic54P1";
import Pic54P2 from "./J.Project/Page3/Pic54P2";
import Pic54P3 from "./J.Project/Page3/Pic54P3";
import Pic55P1 from "./J.Project/Page3/Pic55P1";
import Pic55P2 from "./J.Project/Page3/Pic55P2";
import Pic55P3 from "./J.Project/Page3/Pic55P3";
import MainPage from "./J.Project/Page4/MainPage";
import Pic60P1 from "./J.Project/Page4/Pic60P1";
import Pic60P2 from "./J.Project/Page4/Pic60P2";
import Pic60P3 from "./J.Project/Page4/Pic60P3";
import Pic61P1 from "./J.Project/Page4/Pic61P1";
import Pic61P2 from "./J.Project/Page4/Pic61P2";
import Pic61P3 from "./J.Project/Page4/Pic61P3";
import Pic62P1 from "./J.Project/Page4/Pic62P1";
import Pic62P2 from "./J.Project/Page4/Pic62P2";
import Pic62P3 from "./J.Project/Page4/Pic62P3";
import Pic63P1 from "./J.Project/Page4/Pic63P1";
import Pic63P2 from "./J.Project/Page4/Pic63P2";
import Pic63P3 from "./J.Project/Page4/Pic63P3";
import Pic64P1 from "./J.Project/Page4/Pic64P1";
import Pic64P2 from "./J.Project/Page4/Pic64P2";
import Pic64P3 from "./J.Project/Page4/Pic64P3";
import Pic65P1 from "./J.Project/Page4/Pic65P1";
import Pic65P2 from "./J.Project/Page4/Pic65P2";
import Pic65P3 from "./J.Project/Page4/Pic65P3";
import Pic66P1 from "./J.Project/Page4/Pic66P1";
import Pic66P2 from "./J.Project/Page4/Pic66P2";
import Pic66P3 from "./J.Project/Page4/Pic66P3";
import Pic67P1 from "./J.Project/Page4/Pic67P1";
import Pic67P2 from "./J.Project/Page4/Pic67P2";
import Pic67P3 from "./J.Project/Page4/Pic67P3";
import Pic68P1 from "./J.Project/Page4/Pic68P1";
import Pic68P2 from "./J.Project/Page4/Pic68P2";
import Pic68P3 from "./J.Project/Page4/Pic68P3";
import Header2P1 from "./J.Project/Header2P1";
import Pic70 from "./J.Project/Page5/Pic70";
import Pic80 from "./J.Project/Page5/Pic80";
import Pic801 from "./J.Project/Page5/Pic801";
import Pic802 from "./J.Project/Page5/Pic802";
import Pic803 from "./J.Project/Page5/Pic803";
import Pic80P1 from "./J.Project/Page5/Pic80P1";
import Pic80P2 from "./J.Project/Page5/Pic80P2";
import Pic80P3 from "./J.Project/Page5/Pic80P3";
import Pic81P1 from "./J.Project/Page5/Pic81P1";
import Pic81P2 from "./J.Project/Page5/Pic81P2";
import Pic81P3 from "./J.Project/Page5/Pic81P3";
import Pic82P1 from "./J.Project/Page5/Pic82P1";
import Pic82P2 from "./J.Project/Page5/Pic82P2";
import Pic82P3 from "./J.Project/Page5/Pic82P3";
import Pic83P1 from "./J.Project/Page5/Pic83P1";
import Pic83P2 from "./J.Project/Page5/Pic83P2";
import Pic83P3 from "./J.Project/Page5/Pic83P3";
import Pic84P1 from "./J.Project/Page5/Pic84P1";
import Pic84P2 from "./J.Project/Page5/Pic84P2";
import Pic84P3 from "./J.Project/Page5/Pic84P3";
import Pic85P1 from "./J.Project/Page5/Pic85P1";
import Pic85P2 from "./J.Project/Page5/Pic85P2";
import Pic85P3 from "./J.Project/Page5/Pic85P3";
import Pic86P1 from "./J.Project/Page5/Pic86P1";
import Pic86P2 from "./J.Project/Page5/Pic86P2";
import Pic86P3 from "./J.Project/Page5/Pic86P3";
import Pic87P1 from "./J.Project/Page5/Pic87P1";
import Pic87P2 from "./J.Project/Page5/Pic87P2";
import Pic87P3 from "./J.Project/Page5/Pic87P3";
import Pic88P1 from "./J.Project/Page5/Pic88P1";
import Pic88P2 from "./J.Project/Page5/Pic88P2";
import Pic88P3 from "./J.Project/Page5/Pic88P3";
import Pic89P1 from "./J.Project/Page5/Pic89P1";
import Pic89P2 from "./J.Project/Page5/Pic89P2";
import Pic89P3 from "./J.Project/Page5/Pic89P3";
import Pic90 from "./J.Project/Page6/Pic90";
import Pic90P1 from "./J.Project/Page6/Pic90P1";
import Pic90P2 from "./J.Project/Page6/Pic90P2";
import Pic90P3 from "./J.Project/Page6/Pic90P3";
import Pic91P1 from "./J.Project/Page6/Pic91P1";
import Pic91P2 from "./J.Project/Page6/Pic91P2";
import Pic91P3 from "./J.Project/Page6/Pic91P3";
import Pic92P1 from "./J.Project/Page6/Pic92P1";
import Pic92P2 from "./J.Project/Page6/Pic92P2";
import Pic92P3 from "./J.Project/Page6/Pic92P3";
import Pic93P1 from "./J.Project/Page6/Pic93P1";
import Pic93P2 from "./J.Project/Page6/Pic93P2";
import Pic93P3 from "./J.Project/Page6/Pic93P3";
import Pic94P1 from "./J.Project/Page6/Pic94P1";
import Pic94P2 from "./J.Project/Page6/Pic94P2";
import Pic94P3 from "./J.Project/Page6/Pic94P3";
import Pic95P1 from "./J.Project/Page6/Pic95P1";
import Pic95P2 from "./J.Project/Page6/Pic95P2";
import Pic95P3 from "./J.Project/Page6/Pic95P3";
import Pic99P1 from "./J.Project/Page7/Pic99P1";
import Pic99P2 from "./J.Project/Page7/Pic99P2";
import Pic99P3 from "./J.Project/Page7/Pic99P3";
import Pic100P1 from "./J.Project/Page7/Pic100P1";
import Pic100P2 from "./J.Project/Page7/Pic100P2";
import Pic100P3 from "./J.Project/Page7/Pic100P3";
import Pic101P1 from "./J.Project/Page7/Pic101P1";
import Pic101P2 from "./J.Project/Page7/Pic101P2";
import Pic101P3 from "./J.Project/Page7/Pic101P3";
import Pic102P1 from "./J.Project/Page7/Pic102P1";
import Pic102P2 from "./J.Project/Page7/Pic102P2";
import Pic102P3 from "./J.Project/Page7/Pic102P3";
import Pic103P1 from "./J.Project/Page7/Pic103P1";
import Pic103P2 from "./J.Project/Page7/Pic103P2";
import Pic103P3 from "./J.Project/Page7/Pic103P3";
import MakeUp from "./J.Project/Page8/MakeUp";
import Pic110P1 from "./J.Project/Page8/Pic110P1";
import Pic110P2 from "./J.Project/Page8/Pic110P2";
import Pic110P3 from "./J.Project/Page8/Pic110P3";
import Pic111P1 from "./J.Project/Page8/Pic111P1";
import Pic111P2 from "./J.Project/Page8/Pic111P2";
import Pic111P3 from "./J.Project/Page8/Pic111P3";
import Pic112P1 from "./J.Project/Page8/Pic112P1";
import Pic112P2 from "./J.Project/Page8/Pic112P2";
import Pic112P3 from "./J.Project/Page8/Pic112P3";
import Pic113P1 from "./J.Project/Page8/Pic113P1";
import Pic113P2 from "./J.Project/Page8/Pic113P2";
import Pic113P3 from "./J.Project/Page8/Pic113P3";
import Pic114P1 from "./J.Project/Page8/Pic114P1";
import Pic114P2 from "./J.Project/Page8/Pic114P2";
import Pic114P3 from "./J.Project/Page8/Pic114P3";
import Pic115P1 from "./J.Project/Page8/Pic115P1";
import Pic115P2 from "./J.Project/Page8/Pic115P2";
import Pic115P3 from "./J.Project/Page8/Pic115P3";
import KIDS from "./J.Project/Page9/KIDS";
import Kids1P1 from "./J.Project/Page9/Kids1P1";
import Kids1P2 from "./J.Project/Page9/Kids1P2";
import Kids1P3 from "./J.Project/Page9/Kids1P3";
import Kids2P1 from "./J.Project/Page9/Kids2P1";
import Kids2P2 from "./J.Project/Page9/Kids2P2";
import Kids2P3 from "./J.Project/Page9/Kids2P3";
import Kids3P1 from "./J.Project/Page9/Kids3P1";
import Kids3P2 from "./J.Project/Page9/Kids3P2";
import Kids3P3 from "./J.Project/Page9/Kids3P3";
import Kids4P1 from "./J.Project/Page9/Kids4P1";
import Kids4P2 from "./J.Project/Page9/Kids4P2";
import Kids4P3 from "./J.Project/Page9/Kids4P3";
import Kids5P1 from "./J.Project/Page9/Kids5P1";
import Kids5P2 from "./J.Project/Page9/Kids5P2";
import Kids5P3 from "./J.Project/Page9/Kids5P3";









// // import Skytransition from './Skytransition';
// // import Skynight from './Skynight';

// // import Home1 from "./Baroque/Home1";
// // import Page1 from './Baroque/Page1';
// // import Page2 from './Baroque/Page2';
// // import Page3 from './Baroque/Page3';
// // import Click from './Click';
// // import Flexbox from './Baroque/Flexbox';
// // import P1 from './Netflix/P1';

// // import  Component1  from './Component1';
// // import Component2 from './Component2';
// // import Component3 from './Component3';
// // import Component4 from './Component4';
// // import Component5 from './Component5';
// // import Component6 from './Component6';
// // import Component7 from './Component7';
// // import Component8 from './Component8';
// // import Component9 from './Component9';
// // import Component10 from './Component10';
// // import Component11 from './Component11';

// //import Header from './Header';
// // import Header1 from './Header1';

import { ThemeProvider } from "@material-tailwind/react";



function App() {
  return (
    <ThemeProvider>
      <Router>
          <MainApp />
      </Router>
    </ThemeProvider>
  );
}


function MainApp() {
  const location = useLocation();
  const hideHeaderRoutes = ["/"];
  const hideFooterRoutes = ["/"];
  const shouldHideHeader = hideHeaderRoutes.includes(location.pathname);
  const shouldHideFooter = hideFooterRoutes.includes(location.pathname);

  console.log(location.pathname);

  return (
    <div className="App">
    {!shouldHideHeader && <Header1 />}
        <Routes>
          <Route path="/" element={<Page1/>}/>
          <Route path="/Header2" element={<Header2/>}/>
          <Route path="/Header3" element={<Header3/>}/>
          <Route path="/Header5" element={<Header5/>}/>
          <Route path="/Header6" element={<Header6/>}/>
          <Route path="/Header7" element={<Header7/>}/>
          <Route path="/Header8" element={<Header8/>}/>
          <Route path="/Header9" element={<Header9/>}/>
          <Route path="/Header10" element={<Header10/>}/>
          <Route path="/Header11" element={<Header11/>}/>
          <Route path="/Header12" element={<Header12/>}/>
          <Route path="/Header121" element={<Header121/>}/>
          <Route path="/Header122" element={<Header122/>}/>
          <Route path="/Header13" element={<Header13/>}/>
          <Route path="/FooterC" element={<FooterC/>}/>
          <Route path="/FooterC1" element={<FooterC1/>}/>
          <Route path="/FooterT" element={<FooterT/>}/>
          <Route path="/FooterP" element={<FooterP/>}/>
          <Route path="/FooterPA" element={<FooterPA/>}/>
          <Route path="/FooterAB" element={<FooterAB/>}/>
          <Route path="/H1" element={<H1/>}/>
          <Route path="/HeaderAA" element={<HeaderAA/>}/>
          <Route path="/View" element={<View/>}/>
          <Route path="/Secure" element={<Secure/>}/>
          <Route path="/Hh" element={<Hh/>}/>
<Route path="/Pic1" element={<Pic1/>}/>
<Route path="/Pic1P1" element={<Pic1P1/>}/>
<Route path="/Pic1P2" element={<Pic1P2/>}/>
<Route path="/Pic1P3" element={<Pic1P3/>}/>
<Route path="/Pic2P1" element={<Pic2P1/>}/>
<Route path="/Pic2P2" element={<Pic2P2/>}/>
<Route path="/Pic2P3" element={<Pic2P3/>}/>
<Route path="/Pic3P1" element={<Pic3P1/>}/>
<Route path="/Pic3P2" element={<Pic3P2/>}/>
<Route path="/Pic3P3" element={<Pic3P3/>}/>
<Route path="/Pic4P1" element={<Pic4P1/>}/>
<Route path="/Pic4P2" element={<Pic4P2/>}/>
<Route path="/Pic4P3" element={<Pic4P3/>}/>
<Route path="/Pic5P1" element={<Pic5P1/>}/>
<Route path="/Pic5P2" element={<Pic5P2/>}/>
<Route path="/Pic5P3" element={<Pic5P3/>}/>
<Route path="/Pic6P1" element={<Pic6P1/>}/>
<Route path="/pic6P2" element={<Pic6P2/>}/>
<Route path="/Pic6P3" element={<Pic6P3/>}/>
<Route path="/Pic7P1" element={<Pic7P1/>}/>
<Route path="/pic7P2" element={<Pic7P2/>}/>
<Route path="/Pic7P3" element={<Pic7P3/>}/>
<Route path="/Pic8P1" element={<Pic8P1/>}/>
<Route path="/Pic8P2" element={<Pic8P2/>}/>
<Route path="/Pic8P3" element={<Pic8P3/>}/>
<Route path="/Pic9P1" element={<Pic9P1/>}/> 
<Route path="/Pic9P2" element={<Pic9P2/>}/>
<Route path="/Pic9P3" element={<Pic9P3/>}/>
<Route path="/Pic10P1" element={<Pic10P1/>}/>
<Route path="/Pic10P2" element={<Pic10P2/>}/>
<Route path="/Pic10P3" element={<Pic10P3/>}/>
<Route path="/Pic11P1" element={<Pic11P1/>}/>
<Route path="/Pic11P2" element={<Pic11P2/>}/>
<Route path="/Pic11P3" element={<Pic11P3/>}/>
<Route path="/Pic12P1" element={<Pic12P1/>}/>
<Route path="/Pic12P2" element={<Pic12P2/>}/>
<Route path="/Pic12P3" element={<Pic12P3/>}/>
<Route path="/Pic13P1" element={<Pic13P1/>}/>
<Route path="/Pic13P2" element={<Pic13P2/>}/>
<Route path="/Pic13P3" element={<Pic13P3/>}/>
<Route path="/Pic14P1" element={<Pic14P1/>}/>
<Route path="/Pic14P2" element={<Pic14P2/>}/>
<Route path="/Pic14P3" element={<Pic14P3/>}/>
<Route path="/Pic15P1" element={<Pic15P1/>}/>
<Route path="/Pic15P2" element={<Pic15P2/>}/>
<Route path="/Pic15P3" element={<Pic15P3/>}/>
<Route path="Pic16P1"  element={<Pic16P1/>}/>
<Route path="/Pic16P2" element={<Pic16P2/>}/>
<Route path="/Pic16P3" element={<Pic16P3/>}/>
<Route path="/Pic17P1" element={<Pic17P1/>}/>
<Route path="/Pic17P2" element={<Pic17P2/>}/>
<Route path="/Pic17P3" element={<Pic17P3/>}/>
<Route path="/Pic18P1" element={<Pic18P1/>}/>
<Route path="/Pic18P2" element={<Pic18P2/>}/>
<Route path="/Pic18P3" element={<Pic18P3/>}/>
<Route path="/Pic21P1" element={<Pic21P1/>}/>
<Route path="/Pic21P2" element={<Pic21P2/>}/>
<Route path="/Pic21P3" element={<Pic21P3/>}/>
<Route path="/Pic22P1" element={<Pic22P1/>}/>
<Route path="/Pic22P2" element={<Pic22P2/>}/>
<Route path="/Pic22P3" element={<Pic22P3/>}/>
<Route path="/Pic23P1" element={<Pic23P1/>}/>
<Route path="/Pic23P2" element={<Pic23P2/>}/>
<Route path="/Pic23P3" element={<Pic23P3/>}/>
<Route path="/Pic24P1" element={<Pic24P1/>}/>
<Route path="/Pic24P2" element={<Pic24P2/>}/>
<Route path="/Pic24P3" element={<Pic24P3/>}/>
<Route path="/Pic25P1" element={<Pic25P1/>}/>
<Route path="/Pic25P2" element={<Pic25P2/>}/>
<Route path="/Pic25P3" element={<Pic25P3/>}/>
<Route path="/PIc26P1" element={<Pic26P1/>}/>
<Route path="/Pic26P2" element={<Pic26P2/>}/>
<Route path="/Pic26P3" element={<Pic26P3/>}/>
<Route path="/Pic27P1" element={<Pic27P1/>}/>
<Route path="/Pic27P2" element={<Pic27P2/>}/>
<Route path="/Pic27P3" element={<Pic27P3/>}/>
<Route path="/Pic28P1" element={<Pic28P1/>}/>
<Route path="/Pic28P2" element={<Pic28P2/>}/>
<Route path="/Pic28P3" element={<Pic28P3/>}/>
<Route path="/Pic29P1" element={<Pic29P1/>}/>
<Route path="/Pic29P2" element={<Pic29P2/>}/>
<Route path="/Pic29P3" element={<Pic29P3/>}/>
<Route path="/Pic30P1" element={<Pic30P1/>}/>
<Route path="/Pic30P2" element={<Pic30P2/>}/>
<Route path="/Pic30P3" element={<Pic30P3/>}/>
<Route path="/Pic31P1" element={<Pic31P1/>}/>
<Route path="/Pic31P2" element={<Pic31P2/>}/>
<Route path="/Pic31P3" element={<Pic31P3/>}/>
<Route path="/Pic32P1" element={<Pic32P1/>}/>
<Route path="/Pic32P2" element={<Pic32P2/>}/>
<Route path="/Pic32P3" element={<Pic32P3/>}/>
<Route path="/Pic33P1" element={<Pic33P1/>}/>
<Route path="/Pic33P2" element={<Pic33P2/>}/>
<Route path="/Pic33P3" element={<Pic33P3/>}/>
<Route path="/Pic34P1" element={<Pic34P1/>}/>
<Route path="/Pic34P2" element={<Pic34P2/>}/>
<Route path="/Pic34P3" element={<Pic34P3/>}/>
<Route path="/Pic35P1" element={<Pic35P1/>}/>
<Route path="/Pic35P2" element={<Pic35P2/>}/>
<Route path="/Pic35P3" element={<Pic35P3/>}/>
<Route path="/Pic36P1" element={<Pic36P1/>}/>
<Route path="/Pic36P2" element={<Pic36P2/>}/>
<Route path="/Pic36P3" element={<Pic36P3/>}/>
<Route path="/Pic37P1" element={<Pic37P1/>}/>
<Route path="/Pic37P2" element={<Pic37P2/>}/>
<Route path="/Pic37P3" element={<Pic37P3/>}/>
<Route path="/Pic38P1" element={<Pic38P1/>}/>
<Route path="/Pic38P2" element={<Pic38P2/>}/>
<Route path="/Pic38P3" element={<Pic38P3/>}/>
<Route path="/PP" element={<PP/>}/>
<Route path="/Pic40P1" element={<Pic40P1/>}/>
<Route path="/Pic40P2" element={<Pic40P2/>}/>
<Route path="/Pic40P3" element={<Pic40P3/>}/>
<Route path="/Pic41P1" element={<Pic41P1/>}/>
<Route path="/Pic41P2" element={<Pic41P2/>}/>
<Route path="/Pic41P3" element={<Pic41P3/>}/>
<Route path="/Pic43P1" element={<Pic43P1/>}/>
<Route path="/Pic43P2" element={<Pic43P2/>}/>
<Route path="/Pic43P3" element={<Pic43P3/>}/>
<Route path="/Pic44P1" element={<Pic44P1/>}/>
<Route path="/Pic44P2" element={<Pic44P2/>}/>
<Route path="/Pic44P3" element={<Pic44P3/>}/>
<Route path="/Pic45P1" element={<Pic45P1/>}/>
<Route path="/Pic45P2" element={<Pic45P2/>}/>
<Route path="/Pic45P3" element={<Pic45P3/>}/>
<Route path="/Pic46P1" element={<Pic46P1/>}/>
<Route path="/Pic46P2" element={<Pic46P2/>}/>
<Route path="/Pic46P3" element={<Pic46P3/>}/>
<Route path="/Pic47P1" element={<Pic47P1/>}/>
<Route path="/Pic47P2" element={<Pic47P2/>}/>
<Route path="/Pic47P3" element={<Pic47P3/>}/>
<Route path="/Pic48P1" element={<Pic48P1/>}/>
<Route path="/Pic48P2" element={<Pic48P2/>}/>
<Route path="/Pic48P3" element={<Pic48P3/>}/>
<Route path="/Pic49P1" element={<Pic49P1/>}/>
<Route path="/Pic49P2" element={<Pic49P2/>}/>
<Route path="/Pic49P3" element={<Pic49P3/>}/>
<Route path="/Pic50P1" element={<Pic50P1/>}/>
<Route path="/Pic50P2" element={<Pic50P2/>}/>
<Route path="/Pic50P3" element={<Pic50P3/>}/>
<Route path="/Pic51P1" element={<Pic51P1/>}/>
<Route path="/Pic51P2" element={<Pic51P2/>}/>
<Route path="/Pic51P3" element={<Pic51P3/>}/>
<Route path="/Pic52P1" element={<Pic52P1/>}/>
<Route path="/Pic52P2" element={<Pic52P2/>}/>
<Route path="/Pic52P3" element={<Pic52P3/>}/>
<Route path="/Pic53P1" element={<Pic53P1/>}/>
<Route path="/Pic53P2" element={<Pic53P2/>}/>
<Route path="/Pic53P3" element={<Pic53P3/>}/>
<Route path="/Pic54P1" element={<Pic54P1/>}/>
<Route path="/Pic54P2" element={<Pic54P2/>}/>
<Route path="/Pic54P3" element={<Pic54P3/>}/>
<Route path="/Pic55P1" element={<Pic55P1/>}/>
<Route path="/Pic55P2" element={<Pic55P2/>}/>
<Route path="/Pic55P3" element={<Pic55P3/>}/>
<Route path="/MainPage" element={<MainPage/>}/>
<Route path="/Pic60P1" element={<Pic60P1/>}/>
<Route path="/Pic60P2" element={<Pic60P2/>}/>
<Route path="/Pic60P3" element={<Pic60P3/>}/>
<Route path="/Pic61P1" element={<Pic61P1/>}/>
<Route path="/Pic61P2" element={<Pic61P2/>}/>
<Route path="/Pic61P3" element={<Pic61P3/>}/>
<Route path="/Pic62P1" element={<Pic62P1/>}/>
<Route path="/Pic62P2" element={<Pic62P2/>}/>
<Route path="/Pic62P3" element={<Pic62P3/>}/>
<Route path="/Pic63P1" element={<Pic63P1/>}/>
<Route path="/Pic63P2" element={<Pic63P2/>}/>
<Route path="/Pic63P3" element={<Pic63P3/>}/>
<Route path="/Pic64P1" element={<Pic64P1/>}/>
<Route path="/Pic64P2" element={<Pic64P2/>}/>
<Route path="/Pic64P3" element={<Pic64P3/>}/>
<Route path="/Pic65P1" element={<Pic65P1/>}/>
<Route path="/Pic65P2" element={<Pic65P2/>}/>
<Route path="/Pic65P3" element={<Pic65P3/>}/>
<Route path="/Pic66P1" element={<Pic66P1/>}/>
<Route path="/Pic66P2" element={<Pic66P2/>}/>
<Route path="/Pic66P3" element={<Pic66P3/>}/>
<Route path="/Pic67P1" element={<Pic67P1/>}/>
<Route path="/Pic67P2" element={<Pic67P2/>}/>
<Route path="/Pic67P3" element={<Pic67P3/>}/>
<Route path="/Pic68P1" element={<Pic68P1/>}/>
<Route path="/Pic68P2" element={<Pic68P2/>}/>
<Route path="/Pic68P3" element={<Pic68P3/>}/>
<Route path="/Header2P1" element={<Header2P1/>}/>
<Route path="/Pic70" element={<Pic70/>}/>
<Route path="/Pic80" element={<Pic80/>}/>
<Route path="/Pic801" element={<Pic801/>}/>
<Route path="/Pic802" element={<Pic802/>}/>
<Route path="/Pic803" element={<Pic803/>}/>
<Route path="/Pic80P1" element={<Pic80P1/>}/>
<Route path="/Pic80P2" element={<Pic80P2/>}/>
<Route path="/Pic80P3" element={<Pic80P3/>}/>
<Route path="/Pic81P1" element={<Pic81P1/>}/>
<Route path="/Pic81P2" element={<Pic81P2/>}/>
<Route path="/Pic81P3" element={<Pic81P3/>}/>
<Route path="/Pic82P1" element={<Pic82P1/>}/>
<Route path="/Pic82P2" element={<Pic82P2/>}/>
<Route path="/Pic82P3" element={<Pic82P3/>}/>
<Route path="/Pic83P1" element={<Pic83P1/>}/>
<Route path="/Pic83P2" element={<Pic83P2/>}/>
<Route path="/Pic83P3" element={<Pic83P3/>}/>
<Route path="/Pic84P1" element={<Pic84P1/>}/>
<Route path="/Pic84P2" element={<Pic84P2/>}/>
<Route path="/Pic84P3" element={<Pic84P3/>}/>
<Route path="/Pic85P1" element={<Pic85P1/>}/>
<Route path="/Pic85P2" element={<Pic85P2/>}/>
<Route path="/Pic85P3" element={<Pic85P3/>}/>
<Route path="/Pic86P1" element={<Pic86P1/>}/>
<Route path="/Pic86P2" element={<Pic86P2/>}/>
<Route path="/Pic86P3" element={<Pic86P3/>}/>
<Route path="/Pic87P1" element={<Pic87P1/>}/>
<Route path="/Pic87P2" element={<Pic87P2/>}/>
<Route path="/Pic87P3" element={<Pic87P3/>}/>
<Route path="/Pic88P1" element={<Pic88P1/>}/>
<Route path="/Pic88P2" element={<Pic88P2/>}/>
<Route path="/Pic88P3" element={<Pic88P3/>}/>
<Route path="/Pic89P1" element={<Pic89P1/>}/>
<Route path="/Pic89P2" element={<Pic89P2/>}/>
<Route path="/Pic89P3" element={<Pic89P3/>}/>
<Route path="/Pic90" element={<Pic90/>}/>
<Route path="/Pic90P1" element={<Pic90P1/>}/>
<Route path="/Pic90P2" element={<Pic90P2/>}/>
<Route path="/Pic90P3" element={<Pic90P3/>}/>
<Route path="/Pic91P1" element={<Pic91P1/>}/>
<Route path="/Pic91P2" element={<Pic91P2/>}/>
<Route path="/Pic91P3" element={<Pic91P3/>}/>
<Route path="/Pic92P1" element={<Pic92P1/>}/>
<Route path="/Pic92P2" element={<Pic92P2/>}/>
<Route path="/Pic92P3" element={<Pic92P3/>}/>
<Route path="/Pic93P1" element={<Pic93P1/>}/>
<Route path="/Pic93P2" element={<Pic93P2/>}/>
<Route path="/Pic93P3" element={<Pic93P3/>}/>
<Route path="/Pic94P1" element={<Pic94P1/>}/>
<Route path="/Pic94P2" element={<Pic94P2/>}/>
<Route path="/Pic94P3" element={<Pic94P3/>}/>
<Route path="/Pic95P1" element={<Pic95P1/>}/>
<Route path="/Pic95P2" element={<Pic95P2/>}/>
<Route path="/Pic95P3" element={<Pic95P3/>}/>
<Route path="/Pic99P1" element={<Pic99P1/>}/>
<Route path="/Pic99P2" element={<Pic99P2/>}/>
<Route path="/Pic99P3" element={<Pic99P3/>}/>
<Route path="/Pic100P1" element={<Pic100P1/>}/>
<Route path="/Pic100P2" element={<Pic100P2/>}/>
<Route path="/Pic100P3" element={<Pic100P3/>}/>
<Route path="/Pic101P1" element={<Pic101P1/>}/>
<Route path="/Pic101P2" element={<Pic101P2/>}/>
<Route path="/Pic101P3" element={<Pic101P3/>}/>
<Route path="/Pic102P1" element={<Pic102P1/>}/>
<Route path="/Pic102P2" element={<Pic102P2/>}/>
<Route path="/Pic102P3" element={<Pic102P3/>}/>
<Route path="/Pic103P1" element={<Pic103P1/>}/>
<Route path="/Pic103P2" element={<Pic103P2/>}/>
<Route path="/Pic103P3" element={<Pic103P3/>}/>
<Route path="/MakeUp" element={<MakeUp/>}/>
<Route path="/Pic110P1" element={<Pic110P1/>}/>
<Route path="/Pic110P2" element={<Pic110P2/>}/>
<Route path="/Pic110P3" element={<Pic110P3/>}/>
<Route path="/Pic111P1" element={<Pic111P1/>}/>
<Route path="/Pic111P2" element={<Pic111P2/>}/>
<Route path="/Pic111P3" element={<Pic111P3/>}/>
<Route path="/Pic112P1" element={<Pic112P1/>}/>
<Route path="/Pic112P2" element={<Pic112P2/>}/>
<Route path="/Pic112P3" element={<Pic112P3/>}/>
<Route path="/Pic113P1" element={<Pic113P1/>}/>
<Route path="/Pic113P2" element={<Pic113P2/>}/>
<Route path="/Pic113P3" element={<Pic113P3/>}/>
<Route path="/Pic114P1" element={<Pic114P1/>}/>
<Route path="/Pic114P2" element={<Pic114P2/>}/>
<Route path="/Pic114P3" element={<Pic114P3/>}/>
<Route path="/Pic115P1" element={<Pic115P1/>}/>
<Route path="/Pic115P2" element={<Pic115P2/>}/>
<Route path="/Pic115P3" element={<Pic115P3/>}/>
<Route path="/KIDS" element={<KIDS/>}/>
<Route path="/Kids1P1" element={<Kids1P1/>}/>
<Route path="/Kids1P2" element={<Kids1P2/>}/>
<Route path="/Kids1P3" element={<Kids1P3/>}/>
<Route path="/Kids2P1" element={<Kids2P1/>}/>
<Route path="/Kids2P2" element={<Kids2P2/>}/>
<Route path="/Kids2P3" element={<Kids2P3/>}/>
<Route path="/Kids3P1" element={<Kids3P1/>}/>
<Route path="/Kids3P2" element={<Kids3P2/>}/>
<Route path="/Kids3P3" element={<Kids3P3/>}/>
<Route path="/Kids4P1" element={<Kids4P1/>}/>
<Route path="/Kids4P2" element={<Kids4P2/>}/>
<Route path="/Kids4P3" element={<Kids4P3/>}/>
<Route path="/Kids5P1" element={<Kids5P1/>}/>
<Route path="/Kids5P2" element={<Kids5P2/>}/>
<Route path="/Kids5P3" element={<Kids5P3/>}/>


        </Routes>
        {!shouldHideFooter && <Footer />}
   

    

      {/* <BrowserRouter>

<Routes>
<Route path='/' element={<Home1/>} />
<Route path='/page1' element={<Page1/>} />
<Route path="/Page2" element={<Page2/>}/>
<Route path="/page3" element={<Page3/>}/>
</Routes>
</BrowserRouter>

*/}

      {/* <Click/> */}
      {/* <Flexbox/> */}

      {/* 
<Studentstatecontent>
   <BrowserRouter >
<Navcomponent />
<Routes>
  <Route path='/' element={<Home/>} />
  <Route path='/Service' element={<Service/>} />
  <Route path='contact' element={<Contact />}/>
<Route path='/Studentsstatesample' element={<Studentsstatesample/>} />
<Route path='/Me' element={<Me/>}/>
</Routes>
</BrowserRouter> 
</Studentstatecontent> */}
      {/* 
    <Component1  />
   <Component2 />
   <Component3 />
<Component4 />
<Component5 />
<Component6 />
<Component7 imgUrl = "https://www.junaidjamshed.com/media/wysiwyg/SV-001.jpg"/>
<Component7 imgUrl = "https://www.junaidjamshed.com/media/wysiwyg/grooms-1.jpg"/>
<Component8/>
<Component9 />
<Component10 />
<Component11 />  */}
      {/* <Skynight/> */}
      {/* <Skytransition /> */}
      {/* <h1>Welcome to react.js</h1> */}
      {/* <hr />
      <Header imgUrl = "https://baroque.pk/cdn/shop/files/02_Banner221.jpg?v=1732964925&width=600"  title="first" />
   <hr />
   <Header imgUrl="https://baroque.pk/cdn/shop/files/02_Banner219.jpg?v=1732356569&width=600" title="second"  /> */}

      {/* <Header1 /> */}
      {/*
<P1/>
*/}
    </div>
  );
}

export default App;


