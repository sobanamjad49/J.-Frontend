import React from 'react'
import './Component1.css'
function Component6() {
  return (
    <div>
      
    <div class="container"  style={{marginTop:"40px"}}>
    <div class="row"  style={{marginLeft:"5px"}}>
    <div class="col-12 col-md-12 col-lg-3 "  >
            <img id='src5'  src="https://www.junaidjamshed.com/media/wysiwyg/W-19.jpg" class="img-fluid"  />
<p style={{fontSize:"20px",fontWeight:"500"}}>Kameez Shalwar</p>
<p style={{fontSize:"20px",fontWeight:"bold",lineHeight:"0px"}}>Shop Now</p>

            <img id='src4' src="https://www.junaidjamshed.com/media/wysiwyg/W-20.jpg" class="img-fluid"  />
            <p style={{fontSize:"20px",fontWeight:"500",}}>Waistcoat</p>
            <p style={{fontSize:"20px",fontWeight:"bold",lineHeight:"0px",}}>Shop Now</p>
        </div>
        <div class="col-12 col-md-12 col-lg-7"  >
            <img id='im1' src="https://www.junaidjamshed.com/media/wysiwyg/W-17.jpg" class="img-fluid"   />
            <p style={{fontSize:"20px",fontWeight:"500"}}>Kurta</p>
            <p style={{fontSize:"20px",fontWeight:"bold",lineHeight:"0px"}}>Shop Now</p>
        </div>
    </div>

        </div>
    </div>
  )
}

export default Component6
