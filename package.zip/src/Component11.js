import React from 'react'
import './Component1.css'
function Component11() {
  return (
    <div>
      <div class="container">
        <div class="row"  style={{marginTop:"20px"}}> 
<div  class="col-12 col-md-12 col-lg-3"  >
    <p style={{fontWeight:"600",fontSize:"25px"}}>Need Help?</p>
    <p>+92 21 111 112 111 (9am - 10pm , Mon - Sat)</p>
    <p>junaidjamshed@gmail.com</p>
</div>
<div  class="col-12 col-md-12 col-lg-3">
<p style={{fontWeight:"600",fontSize:"25px"}}>Customer Service</p>
<span>Contact Us
    <br />Delivery & Orders
<br/>Returns & Exchanges
<br/>Terms & Conditions
<br/>Privacy Policy
<br/>Track My Order
<br/>Payment Guide</span>
</div>
<div  class="col-12 col-md-12 col-lg-3">
<p style={{fontWeight:"600",fontSize:"25px"}}>Company</p>
<p>About Us
<br/>Careers
<br/>Store Addresses
<br/>Terms & Conditions</p>

</div>
<div  class="col-12 col-md-12 col-lg-3">
<p style={{fontWeight:"600",fontSize:"25px"}}>FOLLOW US</p>
<img src="https://th.bing.com/th/id/OIP.QHODby_bS81-x2of8vCIhgHaHa?w=4096&h=4096&rs=1&pid=ImgDetMain" height={"40px"} width={"60px"} />
<img src="https://www.kindpng.com/picc/m/20-203688_twitter-icon-transparent-background-twitter-logo-hd-png.png" height={"30px"} width={"40px"} />
<img src="https://th.bing.com/th/id/R.d615fcb54c8d0bc5d367cbba04bb8610?rik=fVRj7cvbxAp9TA&pid=ImgRaw&r=0" height={"45px"} width={"50px"} />
<img src="https://th.bing.com/th/id/OIP.0wjhvLpjGf_-r-1lqG3QAQHaHw?w=860&h=900&rs=1&pid=ImgDetMain"  height={"35px"} width={"40px"} /><br/>
<img src="https://th.bing.com/th/id/OIP.09F15WCuEz8e1c1OwXN1GgHaHa?w=2048&h=2048&rs=1&pid=ImgDetMain"  height={"45px"} width={"50px"} />
<img src="https://static.vecteezy.com/system/resources/previews/018/910/721/non_2x/linkedin-logo-linkedin-symbol-linkedin-icon-free-free-vector.jpg"  height={"45px"} width={"50px"}/>
</div>
        </div>
        </div>
    </div>
  )
}

export default Component11
