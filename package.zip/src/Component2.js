import React from 'react'
import './Component1.css'

function Component2() {
  return (
    <div>
      <div  id='comp2' >
<h1  className='text-capitalize text-center  pt-1'>J.</h1>
      </div>
    </div>
  )
}

export default Component2
