import React from 'react'
import './Component1.css'
function Component9() {
  return (
    <div>
      <div class="container">
        <div class="row"> 
    
<div class="col-12 col-md-12 col-lg-5"><img src="https://www.junaidjamshed.com/media/catalog/product/y/g/ygtl-648-24_1_.jpg?optimize=medium&bg-color=255,255,255&fit=bounds&height=755&width=589&canvas=589:755&dpr=2" class="img-fluid"/>
<p style={{fontSize:"20px",fontWeight:"500"}}>Teen Girls</p>
<p style={{fontSize:"20px",fontWeight:"bold",lineHeight:"0px"}}>Shop Now</p>
</div>
<div class="col-12 col-md-12 col-lg-2">
    <img src="https://www.junaidjamshed.com/media/wysiwyg/W-10.jpg" class="img-fluid"/>
    <p style={{fontSize:"20px",fontWeight:"500"}}>Teen Boys</p>
<p style={{fontSize:"20px",fontWeight:"bold",lineHeight:"0px"}}>Shop Now</p>
</div>
<div class="col-12 col-md-12 col-lg-2"  >

    <img src="https://www.junaidjamshed.com/media/wysiwyg/W-9.jpg" class="img-fluid"/>
    <p style={{fontSize:"20px",fontWeight:"500"}}>Kid Girls</p>
<p style={{fontSize:"20px",fontWeight:"bold",lineHeight:"0px"}}>Shop Now</p>

    </div>
<div class="col-12 col-md-12 col-lg-2" >
    <img src="https://www.junaidjamshed.com/media/wysiwyg/W-8.jpg" class="img-fluid"/>
    <p style={{fontSize:"20px",fontWeight:"500"}}>Kid Boys</p>
<p style={{fontSize:"20px",fontWeight:"bold",lineHeight:"0px"}}>Shop Now</p>
    

</div>
        </div>
        
      </div>
    </div>
  )
}

export default Component9
