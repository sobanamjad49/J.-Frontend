import React from 'react'
import './Component1.css'
function Skytransition() {
  return (
    <div>
      <div id='box1'>
        <div id='box2'></div>
      </div>
    </div>
  )
}

export default Skytransition
