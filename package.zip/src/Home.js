import React from 'react'
// import Studentcontext from './Studentcontext'
function Home() {
// const Studcontext = useContext(Studentcontext)
  return (

       <div style={{ padding: '1.5rem' }}>
  <h1 style={{ fontSize: '2rem', fontWeight: 'bold', textDecoration: 'underline', color: 'blue' }}>
    This is the About Section.
  </h1>
  <h1 style={{ fontSize: '1.5rem', fontWeight: '600', color: 'black' }}>
    {/* <span style={{ color: 'green' }}>Student Name:</span> {Studcontext.name} <br /> */}
    {/* <span style={{ color: 'green' }}>Rollno:</span> {Studcontext.rollno} <br /> */}

  </h1>
   </div>
  )
}

export default Home
