import React from 'react'
import './Component1.css'


function Component10() {
  return (
    <div>
        <div  class="container">
<div style={{backgroundColor:"dimgray",height:"250px",marginTop:"30px"}}>
<p style={{paddingTop:"50px",fontSize:"20px",fontWeight:"700",color:"white"}}>BE THE FIRST</p>
<p style={{fontSize:"18px",fontWeight:"400",color:"white"}}>New arrivals. Exclusive previews. First access to <br/> sales. Sign up to stay in the know.</p>
<input style={{padding:"7px"}} type='text' placeholder='Enter Your Email Address' />
<button style={{padding:"5px",marginLeft:"10px",backgroundColor:"black",color:"white"}}>Sign Up</button>
  


   
      

</div>
</div>
    </div>
  )
}

export default Component10
