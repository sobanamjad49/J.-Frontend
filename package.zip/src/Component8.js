import React from 'react'
import './Component1.css'
function Component8() {
  return (
    <div>
      <div class="container">
<h4 id='txt'>New Arrivals</h4>
<p id='txt1'>Boys & Girls</p>
      </div>
    </div>
  )
}

export default Component8
