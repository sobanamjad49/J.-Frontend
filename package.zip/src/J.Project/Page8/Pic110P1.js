import React, { useState } from "react";
import Spinner from "react-bootstrap/Spinner";
import Accordion from "react-bootstrap/Accordion";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Offcanvas from "react-bootstrap/Offcanvas";
import Carousel from "react-bootstrap/Carousel";
import { Link } from "react-router-dom";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
import "slick-carousel/slick/slick-theme.css";
import "slick-carousel/slick/slick.css";
import Pagination from "react-bootstrap/Pagination";


import Modal from 'react-bootstrap/Modal';
function Pic110P1() {
 
  const [lgShow, setLgShow] = useState(false);
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [index, setIndex] = useState(0);

  const handleSelect = (selectedIndex) => {
    setIndex(selectedIndex);
  };

  let [change, setChange] = useState(
    <img src="https://www.junaidjamshed.com/media/catalog/product/m/a/matte_queen_liquid_lipstick_16_1__1.jpg?width=436&height=560&canvas=436,560&optimize=medium&bg-color=255,255,255&fit=bounds" />
  );
  return (
    <div>
      <div class="container">
        <div class="row">
          <div class="col-12 col-md-6 col-lg-6 ">
            <div className="flex justify-center">{change}</div>
            <div className="flex gap-4 justify-center">
              <img
                className="mt-4"
                onClick={() =>
                  setChange(
                    (change = (
                      <img src="https://www.junaidjamshed.com/media/catalog/product/m/a/matte_queen_liquid_lipstick_16_1__1.jpg?width=436&height=560&canvas=436,560&optimize=medium&bg-color=255,255,255&fit=bounds" />
                    ))
                  )
                }
                src="https://www.junaidjamshed.com/media/catalog/product/m/a/matte_queen_liquid_lipstick_16_1__1.jpg?width=86&height=110&canvas=86,110&optimize=medium&bg-color=255,255,255&fit=bounds"
              />{" "}
              <img
                className="mt-4"
                onClick={() =>
                  setChange(
                    (change = (
                      <img src="https://www.junaidjamshed.com/media/catalog/product/m/a/matte_queen_liquid_lipstick_16_3__1.jpg?width=436&height=560&canvas=436,560&optimize=medium&bg-color=255,255,255&fit=bounds" />
                    ))
                  )
                }
                src="https://www.junaidjamshed.com/media/catalog/product/m/a/matte_queen_liquid_lipstick_16_3__1.jpg?width=86&height=110&canvas=86,110&optimize=medium&bg-color=255,255,255&fit=bounds"
              />{" "}
              <img
                className="mt-4"
                onClick={() =>
                  setChange(
                    (change = (
                      <img src="https://www.junaidjamshed.com/media/catalog/product/m/a/matte_queen_liquid_lipstick_16_2__1.jpg?width=436&height=560&canvas=436,560&optimize=medium&bg-color=255,255,255&fit=bounds" />
                    ))
                  )
                }
                src="https://www.junaidjamshed.com/media/catalog/product/m/a/matte_queen_liquid_lipstick_16_2__1.jpg?width=86&height=110&canvas=86,110&optimize=medium&bg-color=255,255,255&fit=bounds"
              />{" "}
            </div>{" "}
          </div>

          <div class="col-12 col-md-6 col-lg-6 ">
            <div>
              <p className="font-semibold text-lg mt-2">
              MATTE QUEEN LIQUID LIPSTICK
              </p>
              <p className="font-bold text-gray-600">
                SKU #: J-10000111735
              </p>
              <p className="font-bold text-gray-600">
              JLAWN-S-25-101/S SHEER ELEGANCE-01
              </p>
              <p className="font-bold text-gray-600">IN STOCK</p>
              <p className="text-xs text-black underline">
                Be the first to review this product
              </p>
              <span className="text-black text-2xl font-bold ">
              PKR 12,490.00
              </span>
   

              <hr className="mt-3" />
              <div className="flex mt-6">
                <Spinner
                  className="w-4 h-[0.9rem] mt-2 text-green-500"
                  animation="grow"
                />{" "}
                <p className="ml-3 font-bold">
                Limited Stock Alert: Get Yours Before They're Gone!
                
                </p>
              </div>
              <button onClick={handleShow}>
                <button className="border-black  border-2 p-2 lg:w-[350px] lg:h-[53px] w-[20rem] hover:bg-black hover:text-white mt-10 text-lg font-semibold">
                  ADD TO BAG
                </button>
              </button>

              <Offcanvas show={show} onHide={handleClose} placement="end">
                <Offcanvas.Header
                  closeButton
                  className="border-2 border-black bg-slate-100"
                >
                  <Offcanvas.Title className="font-semibold text-sm ml-40">
                    MY BAG
                  </Offcanvas.Title>
                </Offcanvas.Header>
                <Offcanvas.Body>
                  <div className="flex ">
                    <img
                      className="w-24"
                      src="https://www.junaidjamshed.com/media/catalog/product/m/a/matte_queen_liquid_lipstick_14_1_.jpg?width=150&height=150&canvas=150,150&optimize=medium&bg-color=255,255,255&fit=bounds"
                    />

                    <div>
                      <div className="flex">
                        <p className="text-xs font-bold">
                        MATTE QUEEN LIQUID LIPSTICK
                        </p>
                        <img
                          className="w-6 h-5 ml-14"
                          src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQYvZNgwSJFO0HpucBoFCNrRA1noXhds7qVTQ&s"
                        />
                      </div>

                      <div className="flex mt-9">
                        <p className="text-xs font-bold">QTY:</p>
                        <button>
                          <img
                            className="w-2 mt-[0.1rem] ml-1"
                            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTbfo-64GJ9egugzDhnNTynHj0bOkQO8qK68Q&s"
                          />
                        </button>
                        <p className="font-semibold text-xs ml-4 mt-[0.1rem]">
                          1
                        </p>
                        <button>
                        <img
                            className="w-2 mt-[0.1rem] ml-3"
                            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSjA-r16Dow9Wb4OaeWV4457H8E5G2Ejh-TQg&s"
                          />
                        </button>
                       
                        <p className="text-sm font-bold ml-2">PKR 12,490.00</p>
                      </div>
                    </div>
                  </div>
                  <hr className="mt-3" />
                </Offcanvas.Body>
                <div className="flex justify-between bg-slate-100 p-3">
                  <div className="ml-2 font-semibold text-md">
                    CART SUBTOTAL:
                  </div>
                  <div className="ml-2 font-semibold text-md">PKR 12,490.00</div>
                </div>
                <Link to="/Pic110P2">
                  {" "}
                  <p className="hover:underline text-center text-sm font-semibold p-2">
                    VIEW AND EDIT CART
                  </p>
                </Link>
            
                  {" "}
                  <Link to="/Pic110P3">
                    <button className="p-2  m-2 w-96 border-2 border-black hover:bg-black hover:text-white">
                      GO TO CHECKOUT
                    </button>
                  </Link>
              
              </Offcanvas>

          

              <hr className="mt-5" />

              <Accordion>
                <Accordion.Item eventKey="0" className="border-none ">
                  <Accordion.Header className="font-bold text-xs">
                    More Information
                  </Accordion.Header>
                  <Accordion.Body className="!visible !block">
        
                    <div className="flex mt-2 mb-2">
                      <p className="font-bold text-sm">Color</p>
                      <p className="ml-[7.50rem] text-sm">Blue</p>
                    </div>
                    <div className="flex mt-2 mb-2">
                      <p className="font-bold text-sm">Fabric</p>
                      <p className="ml-[7.30rem] text-sm"> Cotton Silk</p>
                    </div>
                    <div className="flex mt-2 mb-2">
                      <p className="font-bold text-sm">Product Category</p>
                      <p className="ml-10 text-sm">3 Piece Stitched</p>
                    </div>
                    <div className="flex mt-2 mb-2">
                      <p className="font-bold text-sm">Season</p>
                      <p className="ml-28 text-sm">Festive Collection</p>
                    </div>
                  </Accordion.Body>
                </Accordion.Item>
                <hr />
                <Accordion.Item eventKey="1" className="border-none ">
                  <Accordion.Header className="font-bold text-xs">
                    Reviews
                  </Accordion.Header>
                  <Accordion.Body className="!visible !block">
                    <p className="text-xs font-bold mt-4">You're reviewing:</p>
                    <p className="font-bold text-xs">
                      LIGHT BEIGE CAMBRIC UNSTITCHED 3PC | JJLS-W-JWU-22-1863
                    </p>
                    <p class="after:content-['*'] after:text-red-600 after:text-xl text-sm font-bold mt-3">
                      {" "}
                      Your Rating{" "}
                    </p>
                    <p className="font-semibold text-sm mt-2">Quality</p>
                    <div className="flex mt-2 ">
                      <img
                        className="w-6 mr-2"
                        src="https://cdn-icons-png.flaticon.com/128/2099/2099045.png"
                      />
                      <img
                        className="w-6 mr-2"
                        src="https://cdn-icons-png.flaticon.com/128/2099/2099045.png"
                      />
                      <img
                        className="w-6 mr-2"
                        src="https://cdn-icons-png.flaticon.com/128/2099/2099045.png"
                      />
                      <img
                        className="w-6 mr-2"
                        src="https://cdn-icons-png.flaticon.com/128/2099/2099045.png"
                      />
                      <img
                        className="w-6"
                        src="https://cdn-icons-png.flaticon.com/128/2099/2099045.png"
                      />
                    </div>
                    <p className="ml-1 after:content-['*'] after:text-red-600 after:text-xl text-xs font-bold mt-3 ">
                      NickName
                    </p>
                    <Form.Control
                      className="mt-2 rounded-none"
                      size="md"
                      type="text"
                    />

                    <p className="ml-1 after:content-['*'] after:text-red-600 after:text-xl text-xs font-bold mt-3 ">
                      Summary
                    </p>
                    <Form.Control
                      className="mt-2 rounded-none"
                      size="md"
                      type="text"
                    />

                    <p className="ml-1 after:content-['*'] after:text-red-600 after:text-xl text-xs font-bold mt-3 ">
                      Review
                    </p>
                    <Form.Control
                      className="mt-2 rounded-none"
                      size="md"
                      type="text"
                    />
                    <button className="text-lg border-black  border-2 p-1  w-[250px] h-[40px] hover:bg-black hover:text-white mt-10  font-semibold">
                      Submit Review
                    </button>
                  </Accordion.Body>
                </Accordion.Item>
              </Accordion>
            </div>
          </div>
        </div>

     
      
     </div>
    </div>
  );
}

export default Pic110P1;

