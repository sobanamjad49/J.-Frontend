import React from "react";
import { Form } from "react-bootstrap";
import axios from "axios";
function Header13() {
  return (
    <div>
      
      <div class="container-fluid">
        <div class="row">
         
          <div class="col-12 col-md-9 col-lg-6">
            <p className="font-normal uppercase text-2xl">
              Create New Customer Account
            </p>
            <p className="font-semibold mt-4 text-2xl">Personal Information</p>
            <hr className="w-full mt-2" />
            <p className="text-sm mt-4 font-bold after:content-['*'] after:text-red-600 after:ml-1 after:font-extrabold after:text-md">
              First Name
            </p>
            <Form.Control
              className="mt-2 rounded-none border-black"
              size="md"
              type="text"
            />
            <p className="text-sm mt-4 font-bold after:content-['*'] after:text-red-600 after:ml-1 after:font-extrabold after:text-md">
              Last Name
            </p>
            <Form.Control
              className="mt-2 rounded-none border-black"
              size="md"
              type="text"
            />
            <input className="mt-6" type="checkbox" />
            <span className="ml-2 text-md font-medium">
              Sign Up for Newsletter
            </span>
            <p className="text-sm mt-7 font-bold ">Alternate Email</p>
            <Form.Control
              className="mt-2 rounded-none border-black"
              size="md"
              type="text"
            />
            <p className="text-sm mt-7 font-bold ">Date Of Birth</p>
            <Form.Control
              className="mt-2 rounded-none border-black"
              size="md"
              type="date"
            />
            <p className="text-sm mt-7 font-bold ">Marital Status</p>
            <Form.Control
              className="mt-2 rounded-none border-black"
              size="md"
              type="text"
            />
            <input className="mt-6" type="checkbox" />
            <span className="ml-2 text-md font-medium">
              Allow remote shopping assistance{" "}
            </span>

            <p className="font-semibold mt-4 text-2xl">Sign-in Information</p>
            <hr className="w-full mt-2" />
            <p className="text-sm mt-4 font-bold after:content-['*'] after:text-red-600 after:ml-1 after:font-extrabold after:text-md">
              Email
            </p>
            <Form.Control
              className="mt-2 rounded-none border-black"
              size="md"
              type="text"
            />
            <p className="text-sm mt-4 font-bold after:content-['*'] after:text-red-600 after:ml-1 after:font-extrabold after:text-md">
              Password
            </p>
            <Form.Control
              className="mt-2 rounded-none border-black"
              size="md"
              type="text"
            />

            <p className="text-sm mt-4 font-bold after:content-['*'] after:text-red-600 after:ml-1 after:font-extrabold after:text-md">
              Confirm Password
            </p>
            <Form.Control
              className="mt-2 rounded-none border-black"
              size="md"
              type="text"
            />
            <input className="mt-6" type="checkbox" />
            <span className="ml-2 text-md font-medium">Show Password</span>
            <p className="text-red-500 text-sm font-semibold mt-7">
              * Required Fields
            </p>
            <p className="font-semibold mt-4 text-2xl">
              Additional Information
            </p>
            <hr className="w-full mt-2" />
            <Form.Control
              className="mt-4 w-60 rounded-none border-black"
              size="md"
              type="text"
              placeholder="Mobile Number"
            />
            <p className="text-sm mt-12 font-bold after:content-['*'] after:text-red-600 after:ml-1 after:font-extrabold after:text-md">
              Please type the letters and numbers below{" "}
            </p>
            <Form.Control
              className="mt-2 rounded-none border-black"
              size="md"
              type="text"
            />
            <div className="flex mt-4">
              <img src="https://www.junaidjamshed.com/media/captcha/base/cbafcd3230c12d3ebd9cf6c8ebcb109a.png" />
              <button className=" h-9 ml-4 p-1 mt-2 border-2 border-black hover:bg-black hover:text-white">
                Reload Captcha
              </button>
            </div>
            <button className=" mb-11 ml-4 p-2 mt-6 border-2 border-black hover:bg-black hover:text-white">
              Create An Account
            </button>
          </div>
        </div>
        </div>
    </div>  

  );
}

export default Header13;
