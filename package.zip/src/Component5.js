import React from 'react'
import './Component1.css'

function Component5() {
  return (
    <div>
     
    <div class="container"  style={{marginTop:"40px"}}>
    <div class="row">
        <div class="col-12 col-md-12 col-lg-7"  >
            <img id='im1' src="https://www.junaidjamshed.com/media/wysiwyg/W-22.jpg" class="img-fluid" />
            <p style={{fontSize:"20px",fontWeight:"500"}}>Kurti</p>
            <p style={{fontSize:"20px",fontWeight:"bold",lineHeight:"0px"}}>Shop Now</p>
        </div>
        <div class="col-12 col-md-12 col-lg-3"  >
            <img id='src7' src="https://www.junaidjamshed.com/media/wysiwyg/W-15.jpg" class="img-fluid"  />
<p style={{fontSize:"20px",fontWeight:"500"}}>Kurti</p>
<p style={{fontSize:"20px",fontWeight:"bold",lineHeight:"0px"}}>Shop Now</p>

            <img id='src6' src="https://www.junaidjamshed.com/media/wysiwyg/W-16.jpg" class="img-fluid"  />
            <p style={{fontSize:"20px",fontWeight:"500"}}>Stitched</p>
            <p style={{fontSize:"20px",fontWeight:"bold",lineHeight:"0px"}}>Shop Now</p>
        </div>
      
    </div>
</div>
    </div>



  )
}

export default Component5




