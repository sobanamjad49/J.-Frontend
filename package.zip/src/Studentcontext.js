// import createcontext from 'react'
// const Studentcontext = createcontext();
// //Studentcontent ka  name say ek variable banya aur ek function call kr dia
// export default Studentcontext;


import { createContext } from 'react'; // Use the correct function name with uppercase 'C'

const Studentcontext = createContext(); // Creating the context

export default Studentcontext; // Exporting the context
