import React from 'react'
import './Component1.css'
function Component7(props) {
  return (
    <div>
      <div class="container">
        <div class="row">
<div class="col-12 col-md-12 col-lg-12" style={{marginTop:"70px"}}>
    <div style={{border:"35px solid linen"}}>
    <img src={props.imgUrl} class="img-fluid" />
</div>
</div>
        </div>
      </div>
    </div>
  )
}

export default Component7
